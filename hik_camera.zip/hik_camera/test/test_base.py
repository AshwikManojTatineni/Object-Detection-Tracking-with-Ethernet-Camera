#!/usr/bin/env python3

import sys
import boxx

sys.path = [boxx.relfile("..")] + sys.path

if __name__ == "__main__":
    from boxx import *
