#!/usr/bin/env python3

from .__info__ import __version__

from .hik_camera import HikCamera
